package echoserver;

import org.quickserver.net.*;
import org.quickserver.net.server.*;

import java.io.*;

public class EchoServer {
	public static void main(String s[])	{
		
		String cmd  = "echoserver.EchoCommandHandler";
		String auth = "echoserver.EchoServerQuickAuthenticator";
		String data = "echoserver.EchoServerPoolableData"; //Poolable

		QuickServer myServer = new QuickServer(cmd);
		myServer.setAuthenticator(auth); 
		myServer.setClientData(data);

		myServer.setPort(4123);
		myServer.setName("Echo Server v 1.0");

		//store data needed to be changed by QSAdminServer
		Object[] store = new Object[]{"12.00"};
		myServer.setStoreObjects(store);

		//config QSAdminServer 
		myServer.setQSAdminServerPort(4124);
		myServer.getQSAdminServer().getServer().setName("EchoAdmin v 1.0");
		try	{
			//add command plugin
			myServer.getQSAdminServer().setCommandPlugin(
				"echoserver.QSAdminCommandPlugin");
			myServer.startQSAdminServer();
			myServer.startServer();
		} catch(AppException e){
			System.out.println("Error in server : "+e);
		} catch(Exception e){
			System.out.println("Error : "+e);
		}
	}
}


