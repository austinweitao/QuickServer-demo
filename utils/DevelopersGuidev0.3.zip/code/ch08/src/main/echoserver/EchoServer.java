package echoserver;

import org.quickserver.net.*;
import org.quickserver.net.server.*;

import java.io.*;
import java.util.logging.*;

public class EchoServer {
	public static void main(String s[])	{
		
		QuickServer myServer = new QuickServer();
		
		//setup logger to log to file
		Logger logger = null;
		FileHandler xmlLog = null;
		FileHandler txtLog = null;
		File log = new File("./log/");
		if(!log.canRead())
			log.mkdir();
		try	{
			logger = Logger.getLogger("org.quickserver.net"); //get qs logger
			logger.setLevel(Level.FINEST);
			xmlLog = new FileHandler("log/EchoServer.xml");
			logger.addHandler(xmlLog);

			logger = Logger.getLogger("echoserver"); //get app logger
			logger.setLevel(Level.FINEST);
			txtLog = new FileHandler("log/EchoServer.txt");
			txtLog.setFormatter(new SimpleFormatter());
			logger.addHandler(txtLog);
			//img : Sets logger to be used for app.
			myServer.setAppLogger(logger); 
		} catch(IOException e){
			System.err.println("Could not create xmlLog FileHandler : "+e);
		}

		//store data needed to be changed by QSAdminServer
		Object[] store = new Object[]{"12.00"};
		myServer.setStoreObjects(store);

		//load QuickServer from xml
		String confFile = "config"+File.separator+"EchoServer.xml";
		Object config[] = new Object[] {confFile};
		if(myServer.initService(config) == true) {
			try	{
				myServer.startQSAdminServer();
				myServer.startServer();
			} catch(AppException e){
				System.out.println("Error in server : "+e);
			} catch(Exception e){
				System.out.println("Error : "+e);
			}
		}
	}
}


